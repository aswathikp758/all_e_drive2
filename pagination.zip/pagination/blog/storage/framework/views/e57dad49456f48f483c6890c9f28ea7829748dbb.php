<h1>Member Lists</h1>
<table style="border: 3px solid black;">
	<style type="text/css">
		tr,td{border: 1px solid black;}
	</style>
	<tr>
	<td>Id</td>
	<td>Name</td>
	<td>Email</td>
	<td>Address</td>
	
</tr>
<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($item['id']); ?></td>
	<td><?php echo e($item['name']); ?></td>
	<td><?php echo e($item['email']); ?></td>
	<td><?php echo e($item['address']); ?></td>
	
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<span>
	<?php echo e($members->links()); ?>

</span>
<style type="text/css">
	.w-5{
		display: none;
	}
</style><?php /**PATH D:\New folder\pagination\blog\resources\views/list.blade.php ENDPATH**/ ?>