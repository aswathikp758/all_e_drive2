<?php echo csrf_field(); ?>
<h1>Profile Page</h1>
<h2>Hello,<?php echo e(session('user')); ?></h2>
<a href="/logout">Logout</a><?php /**PATH D:\New folder\laravelsession\blog\resources\views/profile.blade.php ENDPATH**/ ?>