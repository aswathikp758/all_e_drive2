<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\CustomAuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('registration',[CustomAuthController::class,'registration']);


Route::post('register-user',[CustomAuthController::class,'registerUser'])->name('register-user');

Route::get('login',[CustomAuthController::class,'login']);

Route::post('login-user',[CustomAuthController::class,'loginUser'])->name('login-user');

Route::group(['middleware'=>'user_auth'],function(){
Route::get('/dashboard',[CustomAuthController::class,'dashboard']);


Route::get('/logout',[CustomAuthController::class,'logout']);


});

