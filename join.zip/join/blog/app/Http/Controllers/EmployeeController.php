<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\Facades\DB;

class EmployeeController extends Controller
{
    function show()
        {
            return DB::table('employee')
            ->join('companies','employee.cid',"=",'companies.cid')
            ->where('companies.cid',1)
            ->get();




            
           

        }
}



