<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Users extends Controller
{
    // public function index()
    // {
    //     // --------check if stt
    //    return view('users',['user'=>'ac']);


       
    // }
    // public function about()
    // {
    //      //--------foreach loop in balde
    //    $data=['a','b','c','d'];
    //    return view('foreach',['users'=>$data]);
    // }
    
}
