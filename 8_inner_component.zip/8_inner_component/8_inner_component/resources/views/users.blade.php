
<x-header/>
<h1>User Page</h1>
@include('inner');



