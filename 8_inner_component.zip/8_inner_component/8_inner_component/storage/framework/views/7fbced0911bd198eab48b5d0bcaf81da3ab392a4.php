<div>
    <!-- Act only according to that maxim whereby you can, at the same time, will that it should become a universal law. - Immanuel Kant -->
    <h1> Header Section</h1>
</div><?php /**PATH D:\Laravel8\all\8_inner_component\resources\views/components/header.blade.php ENDPATH**/ ?>