
<form action="users" method="post">
	@csrf
	
	<input type="text" placeholder="Username" name="username"><br>
	<span style="color:red">@error('username'){{$message}}@enderror</span>
	 <br>
	
	<input type="Password" placeholder="Password" name="userpassword"><br>
	<span style="color:red">@error('userpassword'){{$message}}@enderror</span>
	<br>
	<br>
	<button type="submit">Login</button>
</form>