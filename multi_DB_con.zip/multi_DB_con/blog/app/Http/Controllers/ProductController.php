<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\support\Facades\DB;

class ProductController extends Controller
{
    //
    function list()
    {
        //return hello;

       // return DB::table('devices')->get();
        return DB::connection('mysql2')->table('users')->get();

    }
}
