<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Users extends Controller
{
    public function index()
    {
        echo "hi";
    }

    public function about()
    {
    
        return ['name'=>"anil",'age'=>65];   //print static data
    }
    
    public function passdata($user)
    {
    
        echo $user;
    }
}
