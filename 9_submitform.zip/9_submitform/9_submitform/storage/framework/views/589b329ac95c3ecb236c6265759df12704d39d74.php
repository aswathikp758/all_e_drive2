<h1>Login</h1>

<form action="userss" method="post">
	<?php echo csrf_field(); ?>
	<input type="text" placeholder="Username" name="username">
	<br> 
	<input type="Password" placeholder="Password" name="userpassword">
	<br>
	<button type="submit">Login</button>
</form><?php /**PATH D:\Laravel8\all\9_submitform\resources\views/users.blade.php ENDPATH**/ ?>