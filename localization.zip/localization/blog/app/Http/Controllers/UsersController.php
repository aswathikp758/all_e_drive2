<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsersController extends Controller
{
    function viewload()
    {
        // return view("users");

        //----pass data from controller
        return view('users',['users'=>['a','b','c']]);

       
    }


    
}
