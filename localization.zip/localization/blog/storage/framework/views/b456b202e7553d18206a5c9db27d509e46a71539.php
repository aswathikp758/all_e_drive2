<h1><?php echo e(__('profile.welcome')); ?></h1>
<a href=""><?php echo e(__('profile.about')); ?></a>
<a href=""><?php echo e(__('profile.list')); ?></a>
<a href=""><?php echo e(__('profile.contact')); ?></a>






<!-- <h1>welcome to website</h1>
<a href="">About</a>
<a href="">list</a>
<a href="">Contact</a> -->
<?php /**PATH D:\New folder\localization\blog\resources\views/profile.blade.php ENDPATH**/ ?>