<?php
return ['welcome'=>"welcome to website",
     'about'=>'about',
     'list'=>'list',
     'contact'=>'contact'
] 
?>