<h1>{{__('profile.welcome')}}</h1>
<a href="">{{__('profile.about')}}</a>
<a href="">{{__('profile.list')}}</a>
<a href="">{{__('profile.contact')}}</a>






<!-- <h1>welcome to website</h1>
<a href="">About</a>
<a href="">list</a>
<a href="">Contact</a> -->
