<?php if($user=="abc"): ?>
<h3>hi<?php echo e($user); ?></h3>
<?php elseif($user=="xyz"): ?>
<h3>hi<br><?php echo e($user); ?></h3>
<?php else: ?>
<h3>unknown user</h3>
<?php endif; ?>



<?php /**PATH E:\Blubay_IT\Laravel8\all\6_if_statement\6_if_statement\resources\views/users.blade.php ENDPATH**/ ?>