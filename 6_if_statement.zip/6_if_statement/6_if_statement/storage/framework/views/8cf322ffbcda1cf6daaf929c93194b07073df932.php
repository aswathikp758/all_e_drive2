<h1>Upload File</h1>
<form action="upload" method="POST" enctype="multipart/form-Data">
	<?php echo csrf_field(); ?>
	<input type="file" name="file"><br>
	<button type="submit">Upload File</button>
</form><?php /**PATH D:\New folder\uploadfile\blog\resources\views/upload.blade.php ENDPATH**/ ?>