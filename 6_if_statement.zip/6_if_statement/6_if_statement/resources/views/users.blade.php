@if($user=="abc")
<h3>hi{{$user}}</h3>
@elseif($user=="xyz")
<h3>hi<br>{{$user}}</h3>
@else
<h3>unknown user</h3>
@endif



