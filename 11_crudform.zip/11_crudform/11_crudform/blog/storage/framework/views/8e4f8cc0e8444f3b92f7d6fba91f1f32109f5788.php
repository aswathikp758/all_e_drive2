<h1>Update Data</h1>
<form action="/edit" method="POST">
	<?php echo csrf_field(); ?>

	<input type="hidden" name="id" value="<?php echo e($data['id']); ?>"><br>
	<input type="text" name="name" value="<?php echo e($data['name']); ?>"><br>
	<input type="email" name="email" value="<?php echo e($data['email']); ?>"><br>
	<input type="text" name="address" value="<?php echo e($data['address']); ?>"><br>
	<button type="submit">Update</button>
	
</form><?php /**PATH D:\Laravel8\all\11_crudform\blog\resources\views/edit.blade.php ENDPATH**/ ?>