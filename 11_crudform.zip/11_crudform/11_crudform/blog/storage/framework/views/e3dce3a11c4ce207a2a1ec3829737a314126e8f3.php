
<h1>Add Members</h1>
<form action="" method="POST">
<?php echo csrf_field(); ?>
<input type="text" name="name" placeholder="Name"> <br>	
<input type="email" name="email" placeholder="Email"><br>
<input type="text" name="address" placeholder="Address"><br>
<button type="submit">Submit</button>
</form><?php /**PATH E:\Blubay_IT\Laravel8\all\11_crudform\11_crudform\blog\resources\views/addmember.blade.php ENDPATH**/ ?>