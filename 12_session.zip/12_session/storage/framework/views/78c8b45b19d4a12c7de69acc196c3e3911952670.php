<h1>User Login</h1>
<form action="/user" method="POST">
	<?php echo csrf_field(); ?>
	<input type="text" name="user" placeholder="username"><br>
	<span style="color:red"><?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>

	<input type="password" name="password" placeholder="password"><br>
	<span style="color:red"><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
	
	<button type="submit">Login</button>
	

</form><?php /**PATH E:\Blubay_IT\Laravel8\all\12_session\resources\views/login.blade.php ENDPATH**/ ?>