
<!-- print data from route -->
<h1>hello </h1>

<!-------- connect two page using anchor tag ------>

<a href="/aboutt">about</a> 
<a href="/contactt">contact</a><?php /**PATH D:\Laravel8\all\2_connect_anchortag\blog\resources\views/1_view.blade.php ENDPATH**/ ?>