
<!-- print data from route -->
<h1>hello </h1>

<!-------- connect two page using anchor tag ------>

<a href="/aboutt">about</a> 
<a href="/contactt">contact</a>