<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class New_controller extends Controller
{
    //
}
