<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<div class="container">
    <h3>View all image</h3><hr>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Image id</th>
          <th scope="col">Image</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $imageData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($data->id); ?></td>
          <td>
	     <img src="<?php echo e(url('public/Image/'.$data->image)); ?>"
 style="height: 100px; width: 150px;">
	  </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</body>
</html><?php /**PATH E:\all\Blubay_IT\Laravel8\all\laravel-image-upload\laravel-image-upload\resources\views/view_image.blade.php ENDPATH**/ ?>