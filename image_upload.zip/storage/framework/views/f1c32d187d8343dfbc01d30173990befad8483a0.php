<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
  <div class="container">
  <form method="post" action="<?php echo e(route('images.store')); ?>" 
    enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="image">
      <label><h4>Add image</h4></label>
      <input type="file" class="form-control" required name="image">
    </div>

    <div class="post_button">
      <button type="submit" class="btn btn-success">Add</button>
    </div>
  </form>
</div>

</body>
</html><?php /**PATH D:\Laravel8\all\laravel-image-upload\resources\views/add_image.blade.php ENDPATH**/ ?>