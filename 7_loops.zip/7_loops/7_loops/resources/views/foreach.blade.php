@foreach($users as $u)
<h1>{{$u}}</h1>
@endforeach
