<?php for($i=0;$i<10;$i++): ?>
<h4><?php echo e($i); ?></h4>
<?php endfor; ?>



<?php /**PATH D:\New folder\loops\blog\resources\views/users.blade.php ENDPATH**/ ?>