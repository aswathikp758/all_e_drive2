<?php for($i=0;$i<10;$i++): ?>
<h4><?php echo e($i); ?></h4>
<?php endfor; ?>



<?php /**PATH D:\Laravel8\all\7_loops\resources\views/users.blade.php ENDPATH**/ ?>