<?php for($i=10;$i<100;$i++): ?>
<h4><?php echo e($i); ?></h4>
<?php endfor; ?>



<?php /**PATH E:\Blubay_IT\Laravel8\all\7_loops\7_loops\resources\views/users.blade.php ENDPATH**/ ?>