<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UsersController extends Controller
{
    function index()
    {
        return view("users");
    }


    //-----pass data controller to view
    function loadview($name)
    {
        return view("users",['name'=>$name]);
    }
}
