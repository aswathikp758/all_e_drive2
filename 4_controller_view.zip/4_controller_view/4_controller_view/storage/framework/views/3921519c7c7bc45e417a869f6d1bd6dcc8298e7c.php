
<h1>hello from user</h1>


<!-- pass data from controller-->
<h1>hello <?php echo e($name); ?></h1>  





<?php /**PATH E:\Blubay_IT\Laravel8\all\4_controller_view\4_controller_view\resources\views/users.blade.php ENDPATH**/ ?>