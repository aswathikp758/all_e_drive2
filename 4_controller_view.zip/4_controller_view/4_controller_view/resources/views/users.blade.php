
<h1>hello from user</h1>


<!-- pass data from controller-->
<h1>hello {{$name}}</h1>  





