<h1>Member Lists</h1>
<table style="border: 3px solid black;">
	<style type="text/css">
		tr,td{border: 1px solid black;}
	</style>
	<tr>
	<td>Id</td>
	<td>Name</td>
	<td>Email</td>
	<td>Address</td>
	<td colspan="2">Action</td>
</tr>
<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<td><?php echo e($item['id']); ?></td>
	<td><?php echo e($item['name']); ?></td>
	<td><?php echo e($item['email']); ?></td>
	<td><?php echo e($item['address']); ?></td>
	<td><a href="edit/<?php echo e($item['id']); ?>">Update</a></td>
	<td><a href="delete/<?php echo e($item['id']); ?>">Delete</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH D:\New folder\crudform\blog\resources\views/list.blade.php ENDPATH**/ ?>