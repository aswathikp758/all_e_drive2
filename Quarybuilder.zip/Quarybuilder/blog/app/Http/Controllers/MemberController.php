<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MemberController extends Controller
{
    function dboperations()
    {
      // return "code will be here";
       // return DB::table('members')
       // ->where('id',1)
       // ->get();

       // return (array)DB::table('members')->find(12);


       // return DB::table('members')->count();

        // return DB::table('members')
        // ->insert([
        //     'name'=>'anil',
        //     'email'=>'anil@gmail.com',
        //     'address'=>'abc'
        // ]);

        // return DB::table('members')
        // ->where('id',27)
        // ->update([
        //     'name'=>'anilk',
        //     'email'=>'anil@gmail.com',
        //     'address'=>'abc'
        // ]);

          return DB::table('members')
        ->where('id',27)->delete();
       





     }
    
}
