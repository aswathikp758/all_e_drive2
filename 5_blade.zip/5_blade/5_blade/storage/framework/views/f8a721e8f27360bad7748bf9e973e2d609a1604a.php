

 <h1>user page <?php echo e(10+10); ?></h1>
<?php echo e(2+3); ?>                         <!-- calculations -->


<h1>userpage <?php echo e(count($users)); ?></h1>   <!--  find count -->



<?php /**PATH D:\Laravel8\all\5_blade\blog\resources\views/users.blade.php ENDPATH**/ ?>