

 <h1>user page {{10+10}}</h1>
{{2+3}}                         <!-- calculations -->


<h1>userpage {{count($users)}}</h1>   <!--  find count -->








