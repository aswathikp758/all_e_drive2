

 <h1>user page</h1>


<?php /**PATH D:\New folder\middleware\blog\resources\views/users.blade.php ENDPATH**/ ?>